credits = [
["Story", "Robert Planas"],
["Music", "Iñigo Sáez"],
["Programming", "Robert Planas"],
["Powered by", "Blender Game Engine"],
["Powered by", "BGECore"]
]