from core import behavior, utils, media, module
from core import key

class ExampleScene(behavior.Scene):
	def init(self):
		pass
		
	def update(self):
		pass

	def onExit(self):
		pass

#This tells BGECore to use the ExampleScene behavior when the scene "Main" is loaded.
behavior.addScene(ExampleScene, "Main")