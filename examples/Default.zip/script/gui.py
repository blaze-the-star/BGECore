from core import interface, utils, module, behavior, media
from script import constant, control
from bge import logic

class GUI(behavior.Scene):
	def init(self):
		#Set the cursor, hide for the intro video.
		interface.window.setCursor("Cursor")
		interface.window.hideCursor()
		
		#Start the game with intro video
		if not constant.GAME_DEBUG:
			utils.setCamera(self.scene, "GUICamera.001") #Makes the menu desapear.
			media.showScreen()
			media.screen.play("data/video/intro.avi", callback=self.afterVideo)
			media.screen.obj.color.w = 0 #Sets the screen alpha to 0 (invisible).
			media.screen.fadeIn(2) #Sets the screen alpha to 1 with a linear interpolation over 2 seconds.
		
		#Start the game directly
		else: self.afterVideo()
		
	def afterVideo(self):
		utils.setCamera(self.scene, "GUICamera.000")
		interface.window.showCursor()
		media.hideScreen()
		
	def update(self):
		pass
		
behavior.addScene(GUI, constant.CORE_SCENE_GUI)