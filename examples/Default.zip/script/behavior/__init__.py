import script.behavior.scene

ExampleScene = scene.ExampleScene