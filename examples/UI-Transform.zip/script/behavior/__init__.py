import script.behavior.cube
import script.behavior.scene

CubeBehavior = cube.CubeBehavior
ExampleScene = scene.ExampleScene